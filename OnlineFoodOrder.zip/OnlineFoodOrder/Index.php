<?php
    require("./Connection.php");
?>

<html>
  <head>
    <title>Admin Login</title>
    <link rel="stylesheet" href="./assets/css/style.css">
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
  </head>
  <body>
    <div class="container">
      <div class="wrapper">
        <div class="title"><span>ONLINE FOOD ORDER</span></div>
        <form method="POST">
     
            <div class="row">
            <i class="fas fa-user"></i>
            <input type="text" placeholder="Admin Username" name="AdminUsername">
          </div>
          
            <div class="row">
            <i class="fas fa-lock"></i>
            <input type="password" placeholder="Admin Password" name="AdminPassword">
          </div>
          
            <div class="row button">
            <input type="submit" value="Login" name="SignIn">
         
        </form>
      </div>
    </div>
        
<?php

if(isset($_POST['SignIn'])){
    
    $query = "select * from admin_login where Admin_Username='$_POST[AdminUsername]' and Admin_Password='$_POST[AdminPassword]'";
    
    $result = mysqli_query($conn, $query);
    
    if(mysqli_num_rows($result) == 1){
        
        session_start();
        $_SESSION['AdminLogin']=$_POST['AdminUsername'];
        header("location: Dashboard.php");
        
    }else{
        
       echo "<script> alert('Incorrect User Name And Password') </script>";
    }
    
}

?>

  </body>
</html>
