<?php

  require_once("../Connection.php");

  ?>
    
<html>
<head>    
<div style="margin-left: 550px; margin-top: 30px; color: blueviolet">
  <h3>All Hotels</h3>
</div>
  <style>

#myInput {
  background-image: url('../assets/images/search.jpg');
  background-position: 10px 12px;
  background-repeat: no-repeat;
  width: 500px;
  margin-top: 20px;
  margin-left: 700px;
  font-size: 16px;
  padding: 12px 20px 12px 40px;
  border: 1px solid #ddd;
  margin-bottom: 12px;
}

</style>
</head>

<body>
    
    <input type="text" id="myInput" onkeyup="myFunction()" placeholder="Search For Offer.." title="Type in a name">
    
  <table id="myTable">
    <thead>
      <tr class="table">
        <th class="text-center">Offer Id</th>
            <th class="text-center">Offer Image</th>
            <th class="text-center">Offer Name</th>
        <th class="text-center">Offer Coupons</th>
        <th class="text-center" colspan="2">Action</th>
      </tr>
    </thead>
    
    <?php
      $sql="select * from add_offers";
      $result=$conn-> query($sql);
//      $count=1;
      if ($result-> num_rows > 0){
        while ($row=$result-> fetch_assoc()) {
    ?>
    <tr>
      <!--<td><?=$count?></td>-->
      <td><?=$row["Offer_Id"]?></td> 
      <td><img height='120px' width="250px" src='<?=$row["Offer_Image"]?>'></td>
      <td><?=$row["Offer_Name"]?></td>
      <td><?=$row["Offer_Coupons"]?></td>
      <!-- <td><button class="btn btn-primary" >Edit</button></td> -->
      <td><button class="btn btn-danger" style="height:40px" onclick="offerDelete('<?=$row['Offer_Id']?>')">Delete</button></td>
      </tr>
      <?php
//            $count=$count+1;
          }
        }
      ?>
  </table>
    
     <script>
function myFunction() {
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[2];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}
</script>

  <!-- Trigger the modal with a button -->
  <button type="button" class="btn btn-secondary" style="height:40px; margin-left: 120px; color: white" data-toggle="modal" data-target="#myModal">
   Add Offer
  </button>

  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
            <div style="color: red;">
          <h4 class="modal-title">New Offer</h4>
            </div>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body">
          <form  enctype='multipart/form-data' action="./projectAdd/addOffer.php" method="POST">
           
            <div class="form-group">
              <label for="OfferName">Offer Name</label>
              <input type="text" class="form-control" name="OfferName" required>
            </div>
            <div class="form-group">
              <label for="OfferDescription">Offer Description</label>
              <input type="text" class="form-control" name="OfferDescription" required>
            </div>
            <div class="form-group">
              <label for="OfferCoupons">Offer Coupons</label>
              <input type="text" class="form-control" name="OfferCoupons" required>
            </div>
               <div class="form-group">
                <label for="OfferFile">Choose Image</label>
                <input type="file" class="form-control-file" name="OfferFile">
            </div>
              
            <div class="form-group">
              <button type="submit" class="btn btn-secondary" name="AddOffer" style="height:40px; margin-top: 20px;">Add Offer</button>
            </div>
          </form>

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal" style="height:40px; color: white; background-color: black;">Close</button>
        </div>
      </div>
      
    </div>
  </div>
</body>
</html>