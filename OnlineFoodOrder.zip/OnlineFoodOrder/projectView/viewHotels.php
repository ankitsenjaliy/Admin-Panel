<?php

  require_once("../Connection.php");

  ?>
    
<html>
<head>    
<div style="margin-left: 550px; margin-top: 30px; color: blueviolet">
  <h3>All Hotels</h3>
</div>
  <style>

#myInput {
  background-image: url('../assets/images/search.jpg');
  background-position: 10px 12px;
  background-repeat: no-repeat;
  width: 500px;
  margin-top: 20px;
  margin-left: 700px;
  font-size: 16px;
  padding: 12px 20px 12px 40px;
  border: 1px solid #ddd;
  margin-bottom: 12px;
}

</style>
</head>

<body>
    
    <input type="text" id="myInput" onkeyup="myFunction()" placeholder="Search For Hotel.." title="Type in a name">
    
  <table id="myTable">
    <thead>
      <tr class="table">
        <th class="text-center">Hotel Id</th>
        <th class="text-center">Hotel Image</th>
        <th class="text-center">Hotel Name</th>
        <th class="text-center">Hotel Discount</th>
        <th class="text-center" colspan="2">Action</th>
      </tr>
    </thead>
    
    <?php
      $sql="select * from add_hotels";
      $result=$conn-> query($sql);
//      $count=1;
      if ($result-> num_rows > 0){
        while ($row=$result-> fetch_assoc()) {
    ?>
    <tr>
      <!--<td><?=$count?></td>-->
      <td><?=$row["Hotel_Id"]?></td> 
      <td><img height='120px' width="250px" src='<?=$row["Hotel_Image"]?>'></td>
      <td><?=$row["Hotel_Name"]?></td>
      <td><?=$row["Hotel_Discount"]?></td>
      <!-- <td><button class="btn btn-primary" >Edit</button></td> -->
      <td><button class="btn btn-danger" style="height:40px" onclick="hotelDelete('<?=$row['Hotel_Id']?>')">Delete</button></td>
      </tr>
      <?php
//            $count=$count+1;
          }
        }
      ?>
  </table>
    
     <script>
function myFunction() {
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[2];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}
</script>

  <!-- Trigger the modal with a button -->
  <button type="button" class="btn btn-secondary" style="height:40px; margin-left: 120px; color: white" data-toggle="modal" data-target="#myModal">
    New Add Hotel
  </button>

  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
            <div style="color: red;">
          <h4 class="modal-title">Add New Hotel</h4>
            </div>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body">
          <form  enctype='multipart/form-data' action="./projectAdd/addNewHotel.php" method="POST">
           
              <div class="form-group">
              <label for="HotelName">Hotel Name</label>
              <input type="text" class="form-control" name="HotelName" required>
            </div>
               <div class="form-group">
              <label for="HotelDiscount">Hotel Discount</label>
              <input type="text" class="form-control" name="HotelDiscount" required>
            </div>
               <div class="form-group">
                <label for="HotelFile">Choose Image</label>
                <input type="file" class="form-control-file" name="HotelFile">
            </div>
              
            <div class="form-group">
              <button type="submit" class="btn btn-secondary" name="AddHotel" style="height:40px; margin-top: 20px;">Add Hotel</button>
            </div>
          </form>

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal" style="height:40px; color: white; background-color: black;">Close</button>
        </div>
      </div>
      
    </div>
  </div>
</body>
</html>