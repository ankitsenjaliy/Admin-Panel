<?php

  require_once("../Connection.php");

  ?>

<html>
<head>    
    <div style="margin-left: 550px; margin-top: 30px; color: blueviolet">
    <h2>All Customers</h2>
    </div>
    
<style>

#myInput {
  background-image: url('../assets/images/search.jpg');
  background-position: 10px 12px;
  background-repeat: no-repeat;
  width: 500px;
  margin-top: 20px;
  margin-left: 700px;
  font-size: 16px;
  padding: 12px 20px 12px 40px;
  border: 1px solid #ddd;
  margin-bottom: 12px;
}

</style>
</head>

<body>
  <input type="text" id="myInput" onkeyup="myFunction()" placeholder="Search For Customer.." title="Type in a name">
 
  <table id="myTable">
    <thead>
      <tr class="table"> 
        <th class="text-center">Customer Id</th>
        <th class="text-center">Customer Name</th>
        <th class="text-center">Customer Phone No.</th>
        <th class="text-center">Customer Email Id</th>
        <th class="text-center">Customer Address</th>
      </tr>
    </thead>
    
    <?php
      $sql="select * from user_registration";
      $result=$conn-> query($sql);
//      $count=1;
      if ($result-> num_rows > 0){
        while ($row=$result-> fetch_assoc()) {

    ?>
    <tr>
    <!--<td><?=$count?></td>-->
    <td><?=$row["Customer_Id"]?></td>    
    <td><?=$row["Customer_Name"]?></td>
    <td><?=$row["Customer_Phone_No"]?></td>
    <td><?=$row["Customer_Email_Id"]?></td>
    <td><?=$row["Customer_Address"]?></td>
    </tr>
    <?php
//            $count=$count+1;

        }
    }
   
    ?>
  
  </table>
  
<script>
function myFunction() {
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[1];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}
</script>
</body>
</html>