<?php

  require_once("../Connection.php");

?>

<html>

<body>    
    <table id="myTable"  style="margin-left: 0px; margin-top: 20px">
          
       <thead>
           <tr class="table">
            <th class="text-center">Customer Id</th>
            <th class="text-center">Hotel Name</th>
            <th class="text-center">Food Image</th>
            <th class="text-center">Food Name</th>
            <th class="text-center">Total Price</th>
        </tr>
    </thead>
    
    <?php
      $Order_Id = $_GET['Order_Id'];
      $sql="select * from add_orders where Order_Id = '$Order_Id'";
      $result=$conn-> query($sql);

      if ($result -> num_rows > 0){
        while ($row=$result-> fetch_assoc()) {
    ?>
    <tr>
      <td><?=$row["Customer_Id"]?></td>
      <td><?=$row["Hotel_Name"]?></td>
      <td><img height='120px' width="120px" src='<?=$row["Food_Image"]?>'></td>
      <td><?=$row["Food_Name"]?></td>
      <td><?=$row["Total_Price"]?></td>
      </tr>
      <?php
      
          }
        }
      ?>
</table>
</body>
    
</html>    
