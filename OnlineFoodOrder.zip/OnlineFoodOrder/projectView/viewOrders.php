<?php

  require_once("../Connection.php");

  ?>

<html>
<head>
     <div style="margin-left: 550px; margin-top: 30px; color: blueviolet" >
     <h2>All Orders</h2>
     </div> 

<style>
    
 #myInput {
  /*background-image: url('../assets/images/search.jpg');*/
  background-position: 10px 12px;
  background-repeat: no-repeat;
  width: 500px;
  margin-top: 20px;
  margin-left: 700px;
  font-size: 16px;
  padding: 12px 20px 12px 40px;
  border: 1px solid #ddd;
  margin-bottom: 12px;
}

</style>
</head>

<body>
    
    <input type="text" id="myInput" onkeyup="myFunction()" placeholder="Search For Order.." title="Type In A Name">

    <table id="myTable">
      <thead>
        <tr class="table">
        <th class="text-center">Order Id</th>
        <th class="text-center">Customer Name</th>
        <th class="text-center">Customer Phone No.</th>
        <th class="text-center">Customer Address</th>
        <th class="text-center">Order Status</th>
        <th class="text-center">Payment Status</th>
        <th class="text-center">More Details</th>
        </tr>
      </thead>
    
     <?php
     
      $sql="select * from add_orders";
      $result=$conn-> query($sql);
      if ($result-> num_rows > 0){
        while ($row=$result-> fetch_assoc()) {
    ?>
       <tr>
          <td><?=$row["Order_Id"]?></td>
          <td><?=$row["Customer_Name"]?></td>
          <td><?=$row["Customer_Phone_No"]?></td>
          <td><?=$row["Customer_Address"]?></td>
           <?php 
                if($row["Order_Status"]==0){
                            
            ?>
                <td><button class="btn btn-danger" onclick="ChangeOrderStatus('<?=$row['Order_Id']?>')">Pending</button></td>
            <?php
                        
                }else if($row["Order_Status"]==1){
            ?>
                <td><button class="btn btn-success" onclick="ChangeOrderStatus('<?=$row['Order_Id']?>')">Delivered</button></td>
        
            <?php
            }
                if($row["Payment_Status"]==0){
            ?>
                <td><button class="btn btn-danger"  onclick="ChangePaymentStatus('<?=$row['Order_Id']?>')">Unpaid</button></td>
            <?php
                        
            }else if($row["Payment_Status"]==1){
            ?>
                <td><button class="btn btn-success" onclick="ChangePaymentStatus('<?=$row['Order_Id']?>')">Paid</button></td>
            <?php
                }
            ?>
              
        <td><a class="btn btn-primary openPopup" data-href="projectView/viewSingleOrder.php?Order_Id=<?=$row['Order_Id']?>" href="javascript:void(0);">View</a></td>
        </tr>
    <?php
            
        }
      }
    ?>
     
  </table>
   
<div class="modal fade" id="viewModal" role="dialog">
    <div class="modal-dialog modal-lg">
        
      <div class="modal-content">
        <div class="modal-header">
           <div style="color: red;">
          <h4 class="modal-title">Order Details</h4>
           </div>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="order-view-modal modal-body">
            
        </div>
      </div>
    </div>
  </div>
<script>
   
    $(document).ready(function(){
      $('.openPopup').on('click',function(){
        var dataURL = $(this).attr('data-href');
    
        $('.order-view-modal').load(dataURL,function(){
          $('#viewModal').modal({show:true});
        });
      });
    });
 </script>
    
<script>
function myFunction() {
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[0];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}
</script>
</body>
</html>