<?php

  require_once("../Connection.php");

  ?>

<html>
<head>    

<div style="margin-left: 550px; margin-top: 30px; color: blueviolet">
  <h2>All Foods</h2>
</div>

<style>

#myInput {
  background-image: url('../assets/images/search.jpg');
  background-position: 10px 12px;
  background-repeat: no-repeat;
  width: 500px;
  margin-top: 20px;
  margin-left: 700px;
  font-size: 16px;
  padding: 12px 20px 12px 40px;
  border: 1px solid #ddd;
  margin-bottom: 12px;
}

</style>
</head>
<body>
    
     <input type="text" id="myInput" onkeyup="myFunction()" placeholder="Search For Food.." title="Type in a name">
  
     <table id="myTable">
    <thead>
      <tr class="table">
        <th class="text-center">Food Id</th>
        <th class="text-center">Food Image</th>
        <th class="text-center">Hotel Name</th>
        <th class="text-center">Food Name</th>
        <th class="text-center">Food Price</th>
        <th class="text-center" colspan="2">Action</th>
      </tr>
    </thead>
    <?php
      $sql="select * from add_foods";
      $result=$conn-> query($sql);
//      $count=1;
      if ($result-> num_rows > 0){
        while ($row=$result-> fetch_assoc()) {
    ?>
    <tr>
      <!--<td><?=$count?></td>-->
      <td><?=$row["Food_Id"]?></td>
      <td><img height='120px' width="120px" src='<?=$row["Food_Image"]?>'></td>
      <td><?=$row["Hotel_Name"]?></td>
      <td><?=$row["Food_Name"]?></td>
      <td><?=$row["Food_Price"]?></td> 
      <td><button class="btn btn-primary" style="height:40px" onclick="editFood('<?=$row['Food_Id']?>')">Edit</button></td>
      <td><button class="btn btn-danger" style="height:40px" onclick="foodDelete('<?=$row['Food_Id']?>')">Delete</button></td>
      </tr>
      <?php
//            $count=$count+1;
          }
        }
      ?>
  </table>
     
     <script>
function myFunction() {
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[2];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}
</script>

  <!-- Trigger the modal with a button -->
  <button type="button" class="btn btn-secondary " style="height:40px; margin-left: 120px; color: white" data-toggle="modal" data-target="#myModal">
    Add Food
  </button>

  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
            <div style="color: red;">
          <h4 class="modal-title">Add Food</h4>
            </div>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body">
          <form  enctype='multipart/form-data' action="./projectAdd/addFood.php" method="POST">
            
              
                <div class="form-group">
                  <h7><label>Item Food Id</label></h7>
              <select name="ItemFoodId">
                  <option disabled selected>Select Food Id</option>
                <?php

                  $sql="select * from add_item_foods";
                  $result = $conn-> query($sql);

                  if ($result-> num_rows > 0){
                   
                      while($row = $result-> fetch_assoc()){
                        
                      echo"<option value='".$row['Item_Food_Id']."'>".$row['Item_Food_Id'] ."</option>";
                    }
                  }
                ?>
              </select>
              </div>
              
              <div class="form-group">
                  <h7><label>Item Food Name</label></h7>
              <select name="ItemFoodName">
                  <option disabled selected>Select Item Food Name</option>
                <?php

                  $sql="select * from add_item_foods";
                  $result = $conn-> query($sql);

                  if ($result-> num_rows > 0){
                   
                      while($row = $result-> fetch_assoc()){
                        
                      echo"<option value='".$row['Item_Food_Name']."'>".$row['Item_Food_Name'] ."</option>";
                    }
                  }
                ?>
              </select>
              </div>
              
              <div class="form-group">
                  <h7><label>Hotel Name</label></h7>
              <select name="HotelName">
                  <option disabled selected>Select Hotel</option>
                <?php

                  $sql="select * from add_hotels";
                  $result = $conn-> query($sql);

                  if ($result-> num_rows > 0){
                   
                      while($row = $result-> fetch_assoc()){
                        
                      echo"<option value='".$row['Hotel_Name']."'>".$row['Hotel_Name'] ."</option>";
                    }
                  }
                ?>
              </select>
              </div>
              
              <div class="form-group">
              <label for="FoodName">Food Name</label>
              <input type="text" class="form-control" name="FoodName" required>
            </div>
              
            <div class="form-group">
              <label for="FoodDescription">Food Description</label>
              <input type="text" class="form-control" name="FoodDescription" required>
            </div>
              
            <div class="form-group">
              <label for="FoodPrice">Food Price</label>
              <input type="text" class="form-control" name="FoodPrice" required>
            </div>
            
            <div class="form-group">
                <label for="FoodFile">Choose Image</label>
                <input type="file" class="form-control-file" name="FoodFile">
            </div>  
              
            <div class="form-group">
              <button type="submit" class="btn btn-secondary" name="AddFood" style="height:40px; margin-top: 20px;">Add Food</button>
            </div>
          </form>

        </div>
     
          <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal" style="height:40px; color: white; background-color: black;">Close</button>
        </div>
      </div>
      
    </div>
  </div>

</body>
</html>
   