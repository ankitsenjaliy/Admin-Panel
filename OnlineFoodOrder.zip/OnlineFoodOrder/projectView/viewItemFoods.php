<?php

  require_once("../Connection.php");

  ?>

<html>
<head>    

<div style="margin-left: 550px; margin-top: 30px; color: blueviolet">
  <h2>All Foods</h2>
</div>

<style>

#myInput {
  background-image: url('../assets/images/search.jpg');
  background-position: 10px 12px;
  background-repeat: no-repeat;
  width: 500px;
  margin-top: 20px;
  margin-left: 700px;
  font-size: 16px;
  padding: 12px 20px 12px 40px;
  border: 1px solid #ddd;
  margin-bottom: 12px;
}

</style>
</head>
<body>
    
     <input type="text" id="myInput" onkeyup="myFunction()" placeholder="Search For Food.." title="Type in a name">
  
     <table id="myTable">
    <thead>
      <tr class="table">
        <th class="text-center">Item Food Id</th>
        <th class="text-center">Item Food Image</th>
        <th class="text-center">Item Food Name</th>
        <th class="text-center" colspan="2">Action</th>
      </tr>
    </thead>
    <?php
      $sql="select * from add_item_foods";
      $result=$conn-> query($sql);
//      $count=1;
      if ($result-> num_rows > 0){
        while ($row=$result-> fetch_assoc()) {
    ?>
    <tr>
      <!--<td><?=$count?></td>-->
      <td><?=$row["Item_Food_Id"]?></td>
      <td><img height='120px' width="100px" src='<?=$row["Item_Food_Image"]?>'></td>
      <td><?=$row["Item_Food_Name"]?></td>
      <td><button class="btn btn-danger" style="height:40px" onclick="itemFoodDelete('<?=$row['Item_Food_Id']?>')">Delete</button></td>
      </tr>
      <?php
//            $count=$count+1;
          }
        }
      ?>
  </table>
     
     <script>
function myFunction() {
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[2];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}
</script>

  <!-- Trigger the modal with a button -->
  <button type="button" class="btn btn-secondary " style="height:40px; margin-left: 120px; color: white" data-toggle="modal" data-target="#myModal">
    Add Item Food
  </button>

  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
            <div style="color: red;">
          <h4 class="modal-title">Add Item Food</h4>
            </div>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body">
          <form  enctype='multipart/form-data' action="./projectAdd/addItemFood.php" method="POST">
              
              <div class="form-group">
              <label for="ItemFoodName">Item Food Name</label>
              <input type="text" class="form-control" name="ItemFoodName" required>
            </div>
            
            <div class="form-group">
                <label for="ItemFoodFile">Choose Image</label>
                <input type="file" class="form-control-file" name="ItemFoodFile">
            </div>  
              
            <div class="form-group">
              <button type="submit" class="btn btn-secondary" name="AddItemFood" style="height:40px; margin-top: 20px;">Add Item Food</button>
            </div>
          </form>

        </div>
     
          <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal" style="height:40px; color: white; background-color: black;">Close</button>
        </div>
      </div>
      
    </div>
  </div>

</body>
</html>
   