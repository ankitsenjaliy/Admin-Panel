<?php

  require_once("../Connection.php");

  ?>

<html>

    <div class="container p-5" style="margin-left: 50px; margin-top: -50px;">

<div style="margin-top: 30px; color: blue">
  <h2>Edit Food Details</h2>
</div>
        
<?php
	$FoodId=$_POST['record'];
        
         $query="select * from add_foods where Food_Id='$FoodId'";

         $result=mysqli_query($conn,$query);
  
	$numberOfRow=mysqli_num_rows($result);
        
	if($numberOfRow>0){
            
		while($row1=mysqli_fetch_array($result)){
                    
                $FoodId=$row1["Food_Id"];
?>

<form enctype='multipart/form-data' action="./controller/updateFood.php" method="POST">
     
    <div class="form-group">
      <input type="text" class="form-control" name="FoodId" value="<?=$row1['Food_Id']?>" hidden>
    </div>
    
    <div class="form-group">
      <label for="FoodName">Food Name</label>
      <input type="text" class="form-control" name="FoodName" value="<?=$row1['Food_Name']?>">
    </div>
    
    <div class="form-group">
      <label for="FoodDescription">Food Description</label>
      <input type="text" class="form-control" name="FoodDescription" value="<?=$row1['Food_Description']?>">
    </div>
    
    <div class="form-group">
      <label for="FoodPrice">Food Price</label>
      <input type="text" class="form-control" name="FoodPrice" value="<?=$row1['Food_Price']?>">
    </div>
  
<!--    <div class="form-group" style="margin-top: 30px;">
         <img width='120px' height='120px' src='<?=$row1["Food_Image"]?>'>
    </div>-->
    
      <div class="form-group">
            <label for="FoodFile">Choose Image</label>
            <input type="text" name="FoodFile" class="form-control-file" value="<?=$row1['Food_Image']?>" hidden>
            <input type="file" class="form-control-file" name="newFoodImage">
         </div>
  
    <div class="form-group">
      <button type="submit" style="height:40px; color: white; background-color: blue; margin-top: 20px;" name="UpdateFood" class="btn btn-primary">Update Food</button>
    </div>
    <?php
    		}
    	}
    ?>
  </form>

    </div>
</html> 