<?php      
    $localhost = "localhost";
    $username = "root";  
    $password = "";  
    $databasename = "online_food_order";  
       
    $conn = mysqli_connect($localhost, $username, $password, $databasename);  
    
//    if(mysqli_connect_error()) {  
//       
//       echo "Not Connected";
//        
//    } 
?>