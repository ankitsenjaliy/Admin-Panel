<?php
   session_start();
   include_once "./Connection.php";

?>
       
 <nav  class="navbar navbar-expand-lg navbar-light px-5" style="background-color: pink; height: 100px;">
     
       <h4 style="font-size:60px; margin-left: 550px; margin-top: 10px; color: maroon">Online Food Order</h4>
     
    
    
<!--    <div class="user-cart">  
        <?php           
        if(isset($_SESSION['user_id'])){
          ?>
          <a href="" style="text-decoration:none;">
                <i class="fa fa-user mr-5" style="font-size:30px; color:black;"></i>
         </a>
          <?php
        } else {
            ?>
            <a href="" style="text-decoration:none;">
                    <i class="fa fa-sign-in mr-5" style="font-size:60px; color:black;"></i>
            </a>

            <?php
        } ?>
    </div>  -->
</nav>
