<?php

$response = array();
require_once ("../Connection.php");

$Item_Food_Name = $_POST['Item_Food_Name'];

$sql = "select * from add_foods where Item_Food_Name = '$Item_Food_Name'";

$result = mysqli_query($conn, $sql);

if(mysqli_num_rows($result) > 0){
    
    $response["data"] = array();
    
    while ($row = mysqli_fetch_array($result)){
        
        $allFoods = array();
        $allFoods["Food_Id"] = $row["Food_Id"];
        $allFoods["Item_Food_Id"] = $row["Item_Food_Id"];
        $allFoods["Hotel_Name"] = $row["Hotel_Name"];
        $allFoods["Food_Name"] = $row["Food_Name"];
        $allFoods["Food_Description"] = $row["Food_Description"];
        $allFoods["Food_Price"] = $row["Food_Price"];
        $allFoods["Food_Image"] = $row["Food_Image"];
        
        array_push($response["data"], $allFoods);
    }
    
    $response['success'] = true;
    $response['message'] = "All Popular Foods Added";

    }else{
    
    $response['success'] = false;
    $response['message'] = "Not Popular All Foods Added";
}

header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);

?>