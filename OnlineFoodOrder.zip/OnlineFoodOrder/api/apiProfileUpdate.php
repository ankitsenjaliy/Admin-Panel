<?php

require_once ("../Connection.php");

$Customer_Id = $_POST['Customer_Id'];
$Customer_Name = $_POST['Customer_Name'];
$Customer_Phone_No = $_POST['Customer_Phone_No'];
$Customer_Email_Id = $_POST['Customer_Email_Id'];
$Customer_Address = $_POST['Customer_Address'];

$sql = "select * from user_registration where Customer_Id = '$Customer_Id'";

$result = mysqli_query($conn, $sql);

if(mysqli_num_rows($result) > 0){

$sql2 = "update user_registration set Customer_Name = '$Customer_Name', Customer_Phone_No = '$Customer_Phone_No', Customer_Email_Id = '$Customer_Email_Id', Customer_Address = '$Customer_Address' where Customer_Id = '$Customer_Id'";

if(mysqli_query($conn, $sql2) == true){
 
    $response['success'] = true;
    $response['message'] = "Update Customer";
      
}else{
    
    $response['success'] = false;
    $response['message'] = "Not Update Customer";  
}    
    
}else{
    
    $response['success'] = false;
    $response['message'] = "Not Valid Customer Id";
    
}


header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);


?>