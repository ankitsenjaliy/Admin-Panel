<?php

require_once ("../Connection.php");

$Customer_Name = $_POST['Customer_Name'];
$Customer_Phone_No = $_POST['Customer_Phone_No'];
$Customer_Email_Id = $_POST['Customer_Email_Id'];
$Customer_Password = $_POST['Customer_Password'];
$Customer_Address = $_POST['Customer_Address'];

$sql = "select * from user_registration where Customer_Phone_No='$Customer_Phone_No' or Customer_Email_Id='$Customer_Email_Id'";

$result = mysqli_query($conn, $sql);

if(mysqli_num_rows($result) == 0){
    
    $sql2 = "insert into user_registration(Customer_Name, Customer_Phone_No, Customer_Email_Id, Customer_Password, Customer_Address) 
             values ('$Customer_Name', '$Customer_Phone_No', '$Customer_Email_Id', '$Customer_Password', '$Customer_Address')";
    
    $result2 = mysqli_query($conn, $sql2);
    
    if($result2){
        
    $Customer_Id = mysqli_insert_id($conn);  
    $response['success'] = true;
    $response['message'] = "Registration SuccessFully";
    $response['Customer_Id'] = $Customer_Id;
        
    }else{
    $response['success'] = false;
    $response['message'] = "Registeration Failed";
  }
  
} else {
    
    $response['success'] = false;
    $response['message'] = "Email Address And Phone No. Already Used";
}

header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);

?>