<?php
$response = array();
require_once ("../Connection.php");

$sql = "select * from add_item_foods";

$result = mysqli_query($conn, $sql);

if(mysqli_num_rows($result) > 0){
  
    $response["data"] = array();
    
    while ($row = mysqli_fetch_array($result)){
        $popularFood = array();
        $popularFood["Item_Food_Id"] =  $row["Item_Food_Id"];
        $popularFood["Item_Food_Name"] =  $row["Item_Food_Name"];
        $popularFood["Item_Food_Image"] =  $row["Item_Food_Image"];
        
        array_push($response["data"], $popularFood);
    }
    
    $response['success'] = true;
    $response['message'] = "Item Food";
    
}else{
    
    $response['success'] = false;
    $response['message'] = "Not Item Food";
    
}

header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);
?>
