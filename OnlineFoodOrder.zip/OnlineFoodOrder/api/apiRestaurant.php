<?php
$response = array();
require_once ("../Connection.php");

$sql = "select * from add_hotels";

$result = mysqli_query($conn, $sql);

if(mysqli_num_rows($result) > 0){
    
    $response["data"] = array();
    
    while ($row = mysqli_fetch_array($result)){
        
        $hotel = array();
        
        $hotel["Hotel_Id"] =  $row["Hotel_Id"];
        $hotel["Hotel_Name"] =  $row["Hotel_Name"];
        $hotel["Hotel_Discount"] =  $row["Hotel_Discount"];
        $hotel["Hotel_Image"] =  $row["Hotel_Image"];
        
        array_push($response["data"], $hotel);
    }
    
    $response['success'] = true;
    $response['message'] = "Restaurant";
    
}else{
    
    $response['success'] = false;
    $response['message'] = "Not Restaurant";
    
}

header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);
?>
