<?php

$response = array();
require_once ("../Connection.php");

$Customer_Id = $_POST['Customer_Id'];

$sql = "select * from add_cart_foods where Customer_Id = '$Customer_Id'";

$result = mysqli_query($conn, $sql);

if(mysqli_num_rows($result) > 0){
    
    $response["data"] = array();
    
    while ($row = mysqli_fetch_array($result)){
        
        $showCart = array();
        
        $showCart["Food_Id"] = $row["Food_Id"];
        $showCart["Hotel_Name"] = $row["Hotel_Name"];
        $showCart["Food_Name"] = $row["Food_Name"];
        $showCart["Food_Price"] = $row["Food_Price"];
        $showCart["Food_Description"] = $row["Food_Description"];
        $showCart["Food_Image"] = $row["Food_Image"];
        
        array_push($response["data"], $showCart);
    }
    
    $response['success'] = true;
    $response['message'] = "Show Cart";   

    }else{
        
    $response['success'] = false;
    $response['message'] = "Not Valid Customer Id";
    }
    
header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);

?>