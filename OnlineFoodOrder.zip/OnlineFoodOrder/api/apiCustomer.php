<?php

$response = array();
require_once ("../Connection.php");

$Customer_Id = $_POST['Customer_Id'];

$sql = "select * from user_registration where Customer_Id = '$Customer_Id'";

$result = mysqli_query($conn, $sql);

if(mysqli_num_rows($result) > 0){
    
    $response["data"] = array();
    
    while ($row = mysqli_fetch_array($result)){
        
        $customer = array();
        
        $customer["Customer_Name"] = $row["Customer_Name"];
        $customer["Customer_Phone_No"] = $row["Customer_Phone_No"];
        $customer["Customer_Email_Id"] = $row["Customer_Email_Id"];
        $customer["Customer_Password"] = $row["Customer_Password"];
        $customer["Customer_Address"] = $row["Customer_Address"];
        
        array_push($response["data"], $customer);
    }
    
    $response['success'] = true;
    $response['message'] = "Add Customer";
    
}else{
    
    $response['success'] = false;
    $response['message'] = "Not Add Customer";
}

header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);
?>
