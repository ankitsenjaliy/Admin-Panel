<?php

require_once ("../Connection.php");

$Food_Id = $_POST['Food_Id'];

$sql = "delete from add_cart_foods where Food_Id = '$Food_Id'";

$result = mysqli_query($conn, $sql);

if($result){
    
    $response['success'] = true;
    $response['message'] = "Delete Food In Cart";
    
}else{
    
    $response['success'] = false;
    $response['message'] = "Not Delete Food In Cart";
    
}

header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);

?>