<?php

require_once ("../Connection.php");

$Customer_Id = $_POST['Customer_Id'];
$Customer_Phone_No = $_POST['Customer_Phone_No'];
$Customer_Password = $_POST['Customer_Password'];

$sql = "select * from user_registration where Customer_Id='$Customer_Id' and Customer_Phone_No='$Customer_Phone_No' and Customer_Password='$Customer_Password'";

$result = mysqli_query($conn, $sql);

if(mysqli_num_rows($result) > 0){
 
    $response['success'] = true;
    $response['message'] = "Login Customer";
      
}else{
    
    $response['success'] = false;
    $response['message'] = "Not Customer";
    
}

header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);

?>