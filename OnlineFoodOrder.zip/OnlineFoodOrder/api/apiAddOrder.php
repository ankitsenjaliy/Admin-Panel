<?php

require_once ("../Connection.php");

$Customer_Id = $_POST['Customer_Id'];
$Customer_Name = $_POST['Customer_Name'];
$Customer_Phone_No = $_POST['Customer_Phone_No'];
$Customer_Address = $_POST['Customer_Address'];
$Hotel_Id = $_POST['Hotel_Id'];
$Hotel_Name = $_POST['Hotel_Name'];
$Food_Id = $_POST['Food_Id'];
$Food_Name = $_POST['Food_Name'];
$Food_Image = $_POST['Food_Image'];
$Total_Price = $_POST['Total_Price'];
$Order_Status = $_POST['Order_Status'];
$Payment_Status = $_POST['Payment_Status'];
    
    $sql = "insert into add_orders(Customer_Id, Customer_Name, Customer_Phone_No, Customer_Address, Hotel_Id, Hotel_Name, Food_Id, Food_Name, Food_Image, Total_Price, Order_Status, Payment_Status) 
             values ('$Customer_Id', '$Customer_Name', '$Customer_Phone_No', '$Customer_Address', '$Hotel_Id', '$Hotel_Name', '$Food_Id', '$Food_Name', '$Food_Image', '$Total_Price', '$Order_Status', '$Payment_Status')";
    
    $result = mysqli_query($conn, $sql);
    
    if($result){
        
    $Order_Id = mysqli_insert_id($conn);  
    $response['success'] = true;
    $response['message'] = "Order Added SuccessFully";
    $response['Order_Id'] = $Order_Id;
        
    }else{
    $response['success'] = false;
    $response['message'] = "Order Failed";
  
  }

header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);

?>