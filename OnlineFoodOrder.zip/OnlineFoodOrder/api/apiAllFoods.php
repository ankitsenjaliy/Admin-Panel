<?php

$response = array();
require_once ("../Connection.php");

$Hotel_Name = $_POST['Hotel_Name'];

$sql = "select * from add_foods where Hotel_Name = '$Hotel_Name'";

$result = mysqli_query($conn, $sql);

if(mysqli_num_rows($result) > 0){
    
    $response["data"] = array();
    
    while ($row = mysqli_fetch_array($result)){
        
        $allFoods = array();
        $allFoods["Food_Id"] = $row["Food_Id"];
        $allFoods["Hotel_Name"] = $row["Hotel_Name"];
        $allFoods["Food_Name"] = $row["Food_Name"];
        $allFoods["Food_Description"] = $row["Food_Description"];
        $allFoods["Food_Price"] = $row["Food_Price"];
        $allFoods["Food_Image"] = $row["Food_Image"];
        
        array_push($response["data"], $allFoods);
    }
    
    $response['success'] = true;
    $response['message'] = "All Foods Added";

    }else{
    
    $response['success'] = false;
    $response['message'] = "Not All Foods Added";
}

header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);

?>