<?php

require_once ("../Connection.php");

$Rating_No = $_POST['Rating_No'];
$Rating_Description = $_POST['Rating_Description'];

$sql = "insert into rating_application(Rating_No, Rating_Description) values ('$Rating_No','$Rating_Description')";

$result = mysqli_query($conn, $sql);

if($result){
    
    $response['success'] = true;
    $response['message'] = "Rating Added SuccessFully";
    
}else{
    
    $response['success'] = false;
    $response['message'] = "Not Added Rating";
}

header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);

?>