<?php

require_once ("../Connection.php");

$Food_Id = $_POST['Food_Id'];
$Customer_Id = $_POST['Customer_Id'];
$Hotel_Name = $_POST['Hotel_Name'];
$Food_Name = $_POST['Food_Name'];
$Food_Price = $_POST['Food_Price'];
$Food_Description = $_POST['Food_Description'];
$Food_Image = $_POST['Food_Image'];
    
    $sql = "insert into add_cart_foods(Food_Id, Customer_Id, Hotel_Name, Food_Name, Food_Price, Food_Description, Food_Image) 
             values ('$Food_Id', '$Customer_Id','$Hotel_Name', '$Food_Name', '$Food_Price', '$Food_Description', '$Food_Image')";
    
    $result = mysqli_query($conn, $sql);
    
    if($result){
        
    $Cart_Id = mysqli_insert_id($conn);  
    $response['success'] = true;
    $response['message'] = "Food Add To Cart";
    $response['Cart_Id'] = $Cart_Id;
        
    }else{
    $response['success'] = false;
    $response['message'] = "Not Food Add To Cart";
  }

header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);

?>