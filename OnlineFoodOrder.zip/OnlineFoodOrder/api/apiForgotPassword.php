<?php

require_once ("../Connection.php");

$Customer_Email_Id = $_POST['Customer_Email_Id'];
	
$sql = "select * from user_registration where Customer_Email_Id = '$Customer_Email_Id'";
	
$result = mysqli_query($conn, $sql);
	
        if(mysqli_num_rows($result) == 1){
            
		$r = mysqli_fetch_assoc($result);
		$Customer_Password = $r['Customer_Password'];
		$to = $r['Customer_Email_Id'];
		$subject = "Your Recovered Password";

		$message = "Please use this password to login " . $Customer_Password;
		$headers = "From: ankitsenjaliya500@gmail.com";
          	
                if(mail($to, $subject, $message, $headers)){
		
                    echo "Your Password Has Been Send To Your Email Id";   
                }
                
        }else{
		echo "Email Id Does Not Exist";
	}
      
?>