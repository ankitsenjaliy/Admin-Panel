<?php
    require_once("../Connection.php");
    
    if(isset($_POST['AddHotel']))
    {
       
        $HotelName = $_POST['HotelName'];
        $HotelDiscount = $_POST['HotelDiscount'];
        
        $name = $_FILES['HotelFile']['name'];
        $temp = $_FILES['HotelFile']['tmp_name'];
    
        $location="./hotelImage/";
        $image=$location.$name;

        $target_dir="../hotelImage/";
        $finalImage=$target_dir.$name;

        move_uploaded_file($temp,$finalImage);
       
        $query = "insert into add_hotels (Hotel_Name,Hotel_Discount,Hotel_Image) values('$HotelName','$HotelDiscount','$image')";
        
        $result = mysqli_query($conn, $query);
         
         if(!$result)
         { 
              echo mysqli_error($conn);
              header("Location: ../Dashboard.php");
         }
         else
         {
            echo "Records added successfully.";
             header("Location: ../Dashboard.php");
         }
     
    }
        
?>