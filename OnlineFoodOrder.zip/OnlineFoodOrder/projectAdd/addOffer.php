<?php
    require_once("../Connection.php");
    
    if(isset($_POST['AddOffer']))
    {
       
        $OfferName = $_POST['OfferName'];
        $OfferDescription = $_POST['OfferDescription'];
        $OfferCoupons = $_POST['OfferCoupons'];
        
        $name = $_FILES['OfferFile']['name'];
        $temp = $_FILES['OfferFile']['tmp_name'];
    
        $location="./offerImage/";
        $image=$location.$name;

        $target_dir="../offerImage/";
        $finalImage=$target_dir.$name;

        move_uploaded_file($temp,$finalImage);
       
        $query = "insert into add_offers (Offer_Name,Offer_Description,Offer_Coupons,Offer_Image) values('$OfferName','$OfferDescription','$OfferCoupons','$image')";
        
        $result = mysqli_query($conn, $query);
         
         if(!$result)
         { 
              echo mysqli_error($conn);
              header("Location: ../Dashboard.php");
         }
         else
         {
            echo "Records added successfully.";
             header("Location: ../Dashboard.php");
         }
     
    }
        
?>