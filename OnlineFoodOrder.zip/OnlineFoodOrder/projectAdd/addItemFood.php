<?php

require_once("../Connection.php");  
    
    if(isset($_POST['AddItemFood']))
    {
       
        $ItemFoodName= $_POST['ItemFoodName'];
           
        $name = $_FILES['ItemFoodFile']['name'];
        $temp = $_FILES['ItemFoodFile']['tmp_name'];
    
        $location="./itemFoodImage/";
        $image=$location.$name;

        $target_dir="../itemFoodImage/";
        $finalImage=$target_dir.$name;

        move_uploaded_file($temp,$finalImage);
        
        $query = "insert into add_item_foods (Item_Food_Name,Item_Food_Image) values('$ItemFoodName','$image')";
        
        $result = mysqli_query($conn, $query);
        
         if(!$result)
         {
             echo mysqli_error($conn);
             header("Location: ../Dashboard.php");
         }
         else
         {
             echo "Records added successfully.";
             header("Location: ../Dashboard.php");
         }
     
    }

?>
