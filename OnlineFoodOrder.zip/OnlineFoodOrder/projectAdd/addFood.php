<?php
    require_once("../Connection.php");  
    
    if(isset($_POST['AddFood']))
    {
       
        $ItemFoodId = $_POST['ItemFoodId'];
        $ItemFoodName = $_POST['ItemFoodName'];
        
        $HotelName = $_POST['HotelName'];
        $FoodName= $_POST['FoodName'];
        $FoodDescription = $_POST['FoodDescription'];
        $FoodPrice = $_POST['FoodPrice'];
           
        $name = $_FILES['FoodFile']['name'];
        $temp = $_FILES['FoodFile']['tmp_name'];
    
        $location="./foodImage/";
        $image=$location.$name;

        $target_dir="../foodImage/";
        $finalImage=$target_dir.$name;

        move_uploaded_file($temp,$finalImage);
        
        $query = "insert into add_foods (Item_Food_Id,Item_Food_Name,Hotel_Name,Food_Name,Food_Description,Food_Price,Food_Image) values('$ItemFoodId','$ItemFoodName','$HotelName','$FoodName','$FoodDescription','$FoodPrice','$image')";
        
        $result = mysqli_query($conn, $query);
        
         if(!$result)
         {
             echo mysqli_error($conn);
             header("Location: ../Dashboard.php");
         }
         else
         {
             echo "Records added successfully.";
             header("Location: ../Dashboard.php");
         }
     
    }
        
?>