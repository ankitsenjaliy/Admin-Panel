//****************** Customers Details ***************

function showCustomers(){
    $.ajax({
        url:"./projectView/viewCustomers.php",
        method:"post",
        data:{record:1},
        success:function(data){
            $('.allContent-section').html(data);
        }
    });
}


//****************** Hotels Details ***************

function showHotels(){  
    $.ajax({
        url:"./projectView/viewHotels.php",
        method:"post",
        data:{record:1},
        success:function(data){
            $('.allContent-section').html(data);
        }
    });
}

function hotelDelete(id){
    $.ajax({
        url:"./projectDelete/deleteHotel.php",
        method:"post",
        data:{record:id},
        success:function(data){
            alert('Hotel Successfully deleted');
            $('form').trigger('reset');
            showHotels();
        }
    });
}


//****************** Foods Details ***************

function showFoods(){  
    $.ajax({
        url:"./projectView/viewFoods.php",
        method:"post",
        data:{record:1},
        success:function(data){
            $('.allContent-section').html(data);
        }
    });
}

function editFood(id){
    $.ajax({
        url:"./projectEdit/editFood.php",
        method:"post",
        data:{record:id},
        success:function(data){
            $('.allContent-section').html(data);
        }
    });
}

function foodDelete(id){
    $.ajax({
        url:"./projectDelete/deleteFood.php",
        method:"post",
        data:{record:id},
        success:function(data){
            alert('Food Successfully deleted');
            $('form').trigger('reset');
            showFoods();
        }
    });
}


//****************** Foods Details ***************

function showItemFoods(){  
    $.ajax({
        url:"./projectView/viewItemFoods.php",
        method:"post",
        data:{record:1},
        success:function(data){
            $('.allContent-section').html(data);
        }
    });
}

function itemFoodDelete(id){
    $.ajax({
        url:"./projectDelete/deleteItemFood.php",
        method:"post",
        data:{record:id},
        success:function(data){
            alert('Food Item Successfully deleted');
            $('form').trigger('reset');
            showItemFoods();
        }
    });
}


//****************** Offers Details ***************

function showOffers(){  
    $.ajax({
        url:"./projectView/viewOffers.php",
        method:"post",
        data:{record:1},
        success:function(data){
            $('.allContent-section').html(data);
        }
    });
}

function offerDelete(id){
    $.ajax({
        url:"./projectDelete/deleteOffer.php",
        method:"post",
        data:{record:id},
        success:function(data){
            alert('Hotel Successfully deleted');
            $('form').trigger('reset');
            showOffers();
        }
    });
}

//****************** Orders Details ***************

function showOrders(){
    $.ajax({
        url:"./projectView/viewOrders.php",
        method:"post",
        data:{record:1},
        success:function(data){
            $('.allContent-section').html(data);
        }
    });
}

function ChangeOrderStatus(id){
    $.ajax({
       url:"./projectUpdate/updateOrderStatus.php",
       method:"post",
       data:{record:id},
       success:function(data){
           alert('Order Status Updated Successfully');
           $('form').trigger('reset');
           showOrders();
       }
   });
}

function ChangePaymentStatus(id){
    $.ajax({
       url:"./projectUpdate/updatePaymentStatus.php",
       method:"post",
       data:{record:id},
       success:function(data){
           alert('Payment Status Updated Successfully');
           $('form').trigger('reset');
           showOrders();
       }
   });
}




















function showSizes(){  
    $.ajax({
        url:"./adminView/viewSizes.php",
        method:"post",
        data:{record:1},
        success:function(data){
            $('.allContent-section').html(data);
        }
    });
}

function showProductSizes(){  
    $.ajax({
        url:"./adminView/viewProductSizes.php",
        method:"post",
        data:{record:1},
        success:function(data){
            $('.allContent-section').html(data);
        }
    });
}







//delete cart data
function cartDelete(id){
    $.ajax({
        url:"./controller/deleteCartController.php",
        method:"post",
        data:{record:id},
        success:function(data){
            alert('Cart Item Successfully deleted');
            $('form').trigger('reset');
            showMyCart();
        }
    });
}

function eachDetailsForm(id){
    $.ajax({
        url:"./view/viewEachDetails.php",
        method:"post",
        data:{record:id},
        success:function(data){
            $('.allContent-section').html(data);
        }
    });
}



//delete category data


//delete size data
function sizeDelete(id){
    $.ajax({
        url:"./controller/deleteSizeController.php",
        method:"post",
        data:{record:id},
        success:function(data){
            alert('Size Successfully deleted');
            $('form').trigger('reset');
            showSizes();
        }
    });
}


//delete variation data
function variationDelete(id){
    $.ajax({
        url:"./controller/deleteVariationController.php",
        method:"post",
        data:{record:id},
        success:function(data){
            alert('Successfully deleted');
            $('form').trigger('reset');
            showProductSizes();
        }
    });
}

//edit variation data
function variationEditForm(id){
    $.ajax({
        url:"./adminView/editVariationForm.php",
        method:"post",
        data:{record:id},
        success:function(data){
            $('.allContent-section').html(data);
        }
    });
}


//update variation after submit
function updateVariations(){
    var v_id = $('#v_id').val();
    var product = $('#product').val();
    var size = $('#size').val();
    var qty = $('#qty').val();
    var fd = new FormData();
    fd.append('v_id', v_id);
    fd.append('product', product);
    fd.append('size', size);
    fd.append('qty', qty);
   
    $.ajax({
      url:'./controller/updateVariationController.php',
      method:'post',
      data:fd,
      processData: false,
      contentType: false,
      success: function(data){
        alert('Update Success.');
        $('form').trigger('reset');
        showProductSizes();
      }
    });
}
function search(id){
    $.ajax({
        url:"./controller/searchController.php",
        method:"post",
        data:{record:id},
        success:function(data){
            $('.eachCategoryProducts').html(data);
        }
    });
}


function quantityPlus(id){ 
    $.ajax({
        url:"./controller/addQuantityController.php",
        method:"post",
        data:{record:id},
        success:function(data){
            $('form').trigger('reset');
            showMyCart();
        }
    });
}
function quantityMinus(id){
    $.ajax({
        url:"./controller/subQuantityController.php",
        method:"post",
        data:{record:id},
        success:function(data){
            $('form').trigger('reset');
            showMyCart();
        }
    });
}

function checkout(){
    $.ajax({
        url:"./view/viewCheckout.php",
        method:"post",
        data:{record:1},
        success:function(data){
            $('.allContent-section').html(data);
        }
    });
}


function removeFromWish(id){
    $.ajax({
        url:"./controller/removeFromWishlist.php",
        method:"post",
        data:{record:id},
        success:function(data){
            alert('Removed from wishlist');
        }
    });
}


function addToWish(id){
    $.ajax({
        url:"./controller/addToWishlist.php",
        method:"post",
        data:{record:id},
        success:function(data){
            alert('Added to wishlist');        
        }
    });
}