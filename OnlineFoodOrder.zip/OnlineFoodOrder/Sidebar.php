<div class="sidebar" id="mySidebar">
<div class="side-header">
    <!--<img src="./assets/images/1.png" width="80" height="80">--> 
    <h5 style="font-size:30px; margin-top:-30px;">Hello, Admin</h5>
</div>

<!--<hr style="border:1px solid; background-color:black; border-color:white;">-->
    
    <!--<a href="javascript:void(0)">×</a>-->
    <a href="./Dashboard.php" ><i class="fa fa-home"></i>   Dashboard</a>
    <a href="#customers"  onclick="showCustomers()" ><i class="fa fa-users"></i>   Users</a>
    <a href="#hotels"   onclick="showHotels()" ><i class="fa fa-th-large"></i>  Hotels</a>
    <a href="#foods"   onclick="showFoods()" ><i class="fa fa-th"></i>  Foods</a>
    <a href="#item_foods"   onclick="showItemFoods()" ><i class="fa fa-th-large"></i>  Item Foods</a>
    <a href="#offers"   onclick="showOffers()" ><i class="fa fa-th"></i>  Offers</a>    
    <a href="#orders" onclick="showOrders()"><i class="fa fa-list"></i> Orders</a>
 
</div>
 

