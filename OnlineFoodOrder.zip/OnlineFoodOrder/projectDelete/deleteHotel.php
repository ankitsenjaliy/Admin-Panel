<?php

   require_once("../Connection.php");
    
    $HotelId=$_POST['record'];
    
    $query="delete from add_hotels where Hotel_Id='$HotelId'";

    $result=mysqli_query($conn,$query);

    if($result){
        
        echo"Hotel Deleted";
    }
    else{
        
        echo"Hotel Not Deleted";
    }
    
?>