<?php

require_once("../Connection.php");
    
    $ItemFoodId=$_POST['record'];
   
    $query="delete from add_item_foods where Item_Food_Id='$ItemFoodId'";

    $result=mysqli_query($conn,$query);

    if($result){
        
        echo"Food Item Deleted";
        
    }else{
        
        echo"Food Item Not Deleted";
    }


?>