<?php

    require_once("../Connection.php");
    
    $FoodId=$_POST['record'];
   
    $query="delete from add_foods where Food_Id='$FoodId'";

    $result=mysqli_query($conn,$query);

    if($result){
        
        echo"Food Deleted";
        
    }else{
        
        echo"Food Not Deleted";
    }
    
?>