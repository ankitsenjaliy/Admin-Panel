<?php

    require_once("../Connection.php");
    
    $Order_Id = $_POST['record'];
    
    $sql = "select Payment_Status from add_orders where Order_Id='$Order_Id'"; 
    $result=$conn-> query($sql);
  
    $row=$result-> fetch_assoc();
     
    if($row["Payment_Status"] == 0){
         
        $sql2 = "update add_orders set Payment_Status = 1 where Order_Id='$Order_Id'";
        $update = mysqli_query($conn, $sql2);
    
    }else if($row["Payment_Status"] == 1){
         
        $sql3 = "update add_orders set Payment_Status = 0 where Order_Id='$Order_Id'";
        $update2 = mysqli_query($conn, $sql3);
    }

?>