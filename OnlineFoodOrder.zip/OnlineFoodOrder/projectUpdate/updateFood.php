<?php
    require_once("../Connection.php");

    if(isset($_POST['UpdateFood'])){
    
    $FoodId=$_POST['FoodId'];
    $FoodName= $_POST['FoodName'];
    $FoodDescription= $_POST['FoodDescription'];
    $FoodPrice= $_POST['FoodPrice'];
    
    if( isset($_FILES['newFoodImage']) ){
        
        $location="./foodImage/";
        $img = $_FILES['newFoodImage']['name'];
        $tmp = $_FILES['newFoodImage']['tmp_name'];
        $dir = '../foodImage/';
        $ext = strtolower(pathinfo($img, PATHINFO_EXTENSION));
        $valid_extensions = array('jpeg', 'jpg', 'png', 'gif','webp');
        $image =rand(1000,1000000).".".$ext;
        $FinalImage=$location. $image;
        
        if (in_array($ext, $valid_extensions)) {
//            $path = UPLOAD_PATH . $image;
            move_uploaded_file($tmp, $dir.$image);
        }
    }else{
        
        $FinalImage=$_POST['existingImage'];
    }
   
     $query = "update add_foods set Food_Name='$FoodName', Food_Description='$FoodDescription', Food_Price='$FoodPrice', Food_Image='$FinalImage' where Food_Id=$FoodId";
        
     $result = mysqli_query($conn, $query);

       if(!$result){
           
             echo mysqli_error($conn);
             header("Location: ../Dashboard.php#foods.php");
         }
         else{
             
             echo "Records Updated successfully";
             header("Location: ../Dashboard.php#foods.php");
         }
    }
?>